% Compile two necessary utilities

mex utilities/Sm.c;
mex utilities/levinson.c;