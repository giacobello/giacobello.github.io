close all; clc; clear;

T_machinerow=countmotion('machinerow_train.txt','Data Train/',0);
disp(T_machinerow)

T_barbell=countmotion('barbellcurl_train.txt','Data Train/',0);
disp(T_barbell)



