clear; close all; clc;

if 1
fileID = fopen('barbellcurl_train.txt','r');
Tref = [11 10 10 9 10*ones(1,6)];
else
fileID = fopen('machinerow_train.txt','r');
Tref = [10*ones(1,7) 11];
end

LIST = textscan(fileID,'%s\n');
fclose(fileID);

% SSA might be a overkill at the seen SNR 
% so you can enable the low-pass denoising only
LOWPASSonly = false;

[b,a] = butter(6,0.05);

% use only 1st channel
k=1;

% output
Tout = zeros(1, length(LIST{1}));

% iterate through the list

for LISTno = 1:length(LIST{1})
    
    rawdata=csvread(['Data Train/', LIST{1}{LISTno}]);

    %% LOW PASS FILTERING    
    
    denoised_temp = filter(b,a,rawdata(:,k));

    %% SINGULAR SPECTRUM ANALYSIS (probably more helpful at higher SNR)
    
    if LOWPASSonly
    denoised=denoised_temp;
    else 
    denoised=ssa(denoised_temp,100,2);
    end
    
    %% COUNTER OF INSTANCES THROUGH PEAK FINDING
    
    % level normalization
    denoised=denoised+abs(min(denoised));

    % actual peak finder
    [T,~]=peakcounter(denoised,(max(denoised)-min(denoised))/4, 0);
    
    % count of number of peaks
    Tout(LISTno) = length(T);
    
    %% PLOTTING FUNCTION
    
    % sparse vector outlining the nonzero samples  
    locationT = zeros(size(denoised));
    
    % gain for the nonzero samples
    G=max(max(denoised));
    
    % put the nonzero values in the right place
    for t=1:length(T)
    loc=T(t);
    locationT(loc,k)=G*1;
    end
    
    % plot
    figure; subplot(211); plot(rawdata);
            subplot(212); plot(denoised); hold on; plot(locationT);

end

% difference between reference and true data
disp(Tout-Tref)



