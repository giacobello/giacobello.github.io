function [peakidx,peakmag] = peakcounter(xin, sel, thr)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DESCRIPTION
% Robust peak finder and counter.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION
% [peakidx,peakmag] = peakcounter(xin, sel, thr)
% INPUT
%  xin: Original time series
%  sel: The value for selecting data around a peak to be considered
%  thr: Threshold value which peaks must be larger than to be considered
% OUTPUT
%  peakidx: Indices of peak location 
%  peakmag: Magnitude of peaks
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Daniele Giacobello, 8/2015
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

xin=xin(:); % make sure it is a column vector

% DERIVATIVE

dxin = diff(xin); 

dxin(dxin == 0) = -eps; 

% where the derivative changes sign -> local maxima or minima
idx = find(dxin(1:end-1).*dxin(2:end) < 0)+1; 

% values of the function at the maxima 
xpeakvalley = xin(idx);
% starting point (minimum value and starting point for peak/valley alternation)
minmag = min(xpeakvalley);
startpoint = min(xpeakvalley(1), xin(1));
% number of maxima and minima
totlen = length(xpeakvalley);

% ITERATE TO FIND PEAKS

if totlen > 2 % just check that the function is not monotone
    
    % set initial parameters for loop
    tempmag = minmag;
    findpeak = false;
    
    
    % Start on a maxima from the left
    if xpeakvalley(1) >= xpeakvalley(2)
        counter = 0;
    else
        counter = 1;
    end
    
    % preallocate vectors with number of maxima
    maxpeaks = ceil(totlen/2);
    peakLoc = zeros(maxpeaks,1);
    peakMag = zeros(maxpeaks,1);
    
    locidx = 1;
    
    % loop through maxima and minima
    while counter < totlen
        counter = counter+1;
        
        % reset peak finding if peak bigger than the last
        if findpeak
            tempmag = minmag;
            findpeak = false;
        end
        
        % found new peak that was larger than temp mag and selectivity
        if xpeakvalley(counter) > tempmag && xpeakvalley(counter) > startpoint + sel
            tempLoc = counter;
            tempmag = xpeakvalley(counter);
        end
        
        if counter == totlen
            break;
        end
        
        counter = counter+1;
        
        % peak finder
        if ~findpeak && tempmag > sel + xpeakvalley(counter)
            % we found a peak
            findpeak = true;
            
            startpoint = xpeakvalley(counter);
            peakLoc(locidx) = tempLoc;
            peakMag(locidx) = tempmag;
            locidx = locidx+1;
            
        elseif xpeakvalley(counter) < startpoint
            % we found a valley so we reset the left start point
            startpoint = xpeakvalley(counter);
            
        end
    end
    
    % check end points
    if ~findpeak
    
        if xpeakvalley(end) > tempmag && xpeakvalley(end) > startpoint + sel
            
            peakLoc(locidx) = totlen;
            peakMag(locidx) = xpeakvalley(end);
            locidx = locidx + 1;
        
        elseif tempmag > min(xin(end), xpeakvalley(end)) + sel
            
            peakLoc(locidx) = tempLoc;
            peakMag(locidx) = tempmag;
            locidx = locidx + 1;
        
        end
        
    end
    
    % create output
    peakidx = idx(peakLoc(1:locidx-1));
    peakmag = peakMag(1:locidx-1);
    
else
    
    [peakmag,peakidx] = max(xpeakvalley);

end

% Apply threshold value as last check 
m = peakmag>thr;
peakidx = peakidx(m);
peakmag = peakmag(m);




