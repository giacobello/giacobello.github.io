function yrec=ssa(x,L,I)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DESCRIPTION
% Function for Singular Spectrum Analysis (SSA):
% decomposes a time series into oscillatory components and
% noise. This function only outputs the oscillatory component.
%
% It includes four steps: Embedding, Singular Value
% Decomposition (SVD), Grouping, and Reconstruction.
%
% see: https://en.wikipedia.org/wiki/Singular_spectrum_analysis
% for more details
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUNCTION
% y=ssa(x,L,I)
% INPUT
%  x: Original time series
%  L: Window length for embedding
%  I: Eigenvector component be used to reconstruct the signal
% OUTPUT
%  y: Reconstructed time series
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Daniele Giacobello, 8/2015
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x=x(:); % make sure it is a column vector

% Embedding 

N=length(x); 

if L>N/2;
    L=N-L;
end

K=N-L+1;
X=zeros(L,K);  

for i=1:K
    X(1:L,i)=x(i:L+i-1); 
end
    
% SVD

S=X*X'; 
[EigVec,~]=eig(S);

EigVec=fliplr(EigVec); 
PC=(X')*EigVec; 
   
% Grouping (simplified version as we need only the oscillatory component)

PCt=PC';
rec=EigVec(:,I)*PCt(I,:);

% Reconstruction

yrec=zeros(N,1);  
Ltemp=min(L,K);
Ktemp=max(L,K);

for k=0:Ltemp-2
    for m=1:k+1;
        yrec(k+1)=yrec(k+1)+(1/(k+1))*rec(m,k-m+2);
    end
end

for k=Ltemp-1:Ktemp-1
    for m=1:Ltemp;
        yrec(k+1)=yrec(k+1)+(1/(Ltemp))*rec(m,k-m+2);
    end
end

for k=Ktemp:N
    for m=k-Ktemp+2:N-Ktemp+1;
        yrec(k+1)=yrec(k+1)+(1/(N-k))*rec(m,k-m+2);
    end
end



