function Tout = countmotion(file,folder,plotting)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Tout = countmotion(file,folder,plotting)
%
% This function read from the list containing the csv separated files
% and outputs the count for each given file
%
% INPUT:
%     file: the list containing the csv sepatated files
%   folder: the folder containing the sensor data
% plotting: this would plot the data (upper pane) 
%           the denoised signal with the estimated peak location (lower pane)
%
% OUTPUT:
%    Tout: vector with the count of repetition for all the files in
%          "file"
%  
% EXAMPLE:
%   T_machinerow = count('machinerow_train.txt','Data Train/',0);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Daniele Giacobello, 8/2015
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


fileID = fopen(file,'r');


LIST = textscan(fileID,'%s\n');
fclose(fileID);

% SSA might be a overkill at the seen SNR 
% so you can enable the low-pass denoising only
LOWPASSonly = false;

[b,a] = butter(6,0.05);

% use only 1st channel
k=1;

% output
Tout = zeros(1, length(LIST{1}));

% iterate through the list

for LISTno = 1:length(LIST{1})
    
    rawdata=csvread([folder, LIST{1}{LISTno}]);

    %% LOW PASS FILTERING    
    
    denoised_temp = filter(b,a,rawdata(:,k));

    %% SINGULAR SPECTRUM ANALYSIS (probably more helpful at higher SNR)
    
    if LOWPASSonly
    denoised=denoised_temp;
    else 
    denoised=ssa(denoised_temp,100,2);
    end
    
    %% COUNTER OF INSTANCES THROUGH PEAK FINDING
    
    % level normalization
    denoised=denoised+abs(min(denoised));

    % actual peak finder
    [T,~]=peakcounter(denoised,(max(denoised)-min(denoised))/4, 0);
    
    % count of number of peaks
    Tout(LISTno) = length(T);
    
    %% PLOTTING FUNCTION
    if plotting
    % sparse vector outlining the nonzero samples  
    locationT = zeros(size(denoised));
    
    % gain for the nonzero samples
    G=max(max(denoised));
    
    % put the nonzero values in the right place
    for t=1:length(T)
    loc=T(t);
    locationT(loc,k)=G*1;
    end
    
    % plot
    figure; subplot(211); plot(rawdata);
            subplot(212); plot(denoised); hold on; plot(locationT);
    end
end

% difference between reference and true data

if plotting
disp(Tout)
end



